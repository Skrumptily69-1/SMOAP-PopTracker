-- put logic functions here using the Lua API: https://github.com/black-sliver/PopTracker/blob/master/doc/PACKS.md#lua-interface
-- don't be afraid to use custom logic functions. it will make many things a lot easier to maintain, for example by adding logging.
-- to see how this function gets called, check: locations/locations.json
-- example:
function has_more_then_n_moons(kingdom, n)
    local moon_code = string.lower(kingdom) .. "_kingdom_power_moon"
    local moon_obj = Tracker:FindObjectForCode(moon_code)
    if not moon_obj then return 0 end

    local count = moon_obj.AcquiredCount or 0
    if count > tonumber(n) then
        return 1
    end
        return 0
end 

function onSlotData(slot_data)
    if slot_data.moon_requirements then
        MOON_REQS = slot_data.moon_requirements
        print("Moon Requiremnts loaded", MOON_REQS)
    end
end

function has_capture()
    